Python version: Python 3.12.3

File Structure
- function.py is function's code.
- main.py is example of function's usage.
```shell
python main.py
```

- test_nested_json.py is test file.
```shell
python -m unittest test_nested_json.py
```